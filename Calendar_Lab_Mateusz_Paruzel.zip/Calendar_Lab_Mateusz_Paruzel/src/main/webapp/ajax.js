/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */

function getTable(name1, name2, tableId) {
    
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        console.log(this.responseText.split("_"));
        let[, second, third] = this.responseText.split("_");
      document.getElementById("title").innerHTML = second;
     document.getElementById(tableId).innerHTML = third;
    }
  };
  xhttp.open("GET", "CalendarServlet?inputText1=" + document.getElementById(name1).value+ "&inputText2="+document.getElementById(name2).value, true);
  xhttp.send();
}


//http://localhost:8080/Calendar_Lab_Mateusz_Paruzel/CalendarServlet?inputText1=12&inputText2=2055&button=Generuj+kalendarz