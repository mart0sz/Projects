
package pl.polsl.lab.model;
/**
 * @author Mateusz Paruzel
 * @version 2.2
 * The package contains the application model
 */