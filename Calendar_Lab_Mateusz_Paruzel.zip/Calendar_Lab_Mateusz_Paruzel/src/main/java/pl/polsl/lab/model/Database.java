package pl.polsl.lab.model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Mateusz Paruzel
 * @version 5.1
 */
/**
 *Class which represents Database
 */
public class Database {
    /**
     * Method which allows connection to database
     */
    public void createTables() {

        try {
            // loading the JDBC driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println(cnfe.getMessage());
            return;
        }

        // make a connection to DB
        try (Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CalendarBase", "app", "app")) {
            Statement statement = con.createStatement();
            statement.executeUpdate("CREATE TABLE MONTHS "
                    + "(id DECIMAL PRIMARY KEY, name VARCHAR(12), "
                    + "days_number DECIMAL, id_year DECIMAL ) FOREIGN KEY(id_year_fk)) REFERENCES YEARS(id_year) ");
            System.out.println("Table created");
             statement.executeUpdate("CREATE TABLE YEARS "
                    + "(id_year DECIMAL PRIMARY KEY, leap BOOLEAN ");
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
    }
    /**
     * Method which deletes data from Month table
     * @param id_year - id of the year
     */
   public void deleteDataFromMonths(int id_year) {
        
        try {
            // loading the JDBC driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println(cnfe.getMessage());
            return;
        }

        // make a connection to DB
        try (Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CalendarBase", "app", "app")) {
            Statement statement = con.createStatement();
            // Usuwamy dane z tabeli
            int numberOfDeletedRows = statement.executeUpdate("DELETE FROM MONTHS WHERE id_year = " + id_year);
            System.out.println("Data removed: " + numberOfDeletedRows + " rows");
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
    }
      /**
       * Method which inserts data to table Months
       * @param name - name of Months
       * @param days_num - number of days
       * @param id_year - id of the year
       */
       public void insertDataMonths(String name, int days_num, int id_year) {
        
        try {
            // loading the JDBC driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println(cnfe.getMessage());
            return;
        }

        // make a connection to DB
        try (Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CalendarBase", "app", "app")) {
            Statement statement = con.createStatement();
            statement.executeUpdate("INSERT INTO MONTHS(name, days_number, id_year) VALUES ("+name + "," + days_num + ","+  id_year + ")");
            System.out.println("Data inserted");
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
    }
       /**
        * Method which prints data from Month table
        */
       public void selectDataFromMonths() {

        try {
            // loading the JDBC driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println(cnfe.getMessage());
            return;
        }

        // make a connection to DB
        try (Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CalendarBase", "app", "app")) {
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM MONTHS");
            // Przeglądamy otrzymane wyniki
            System.out.printf("|%-3s|%-12s|%-10s|%-5s|\n", "ID", "Name", "Days_number", "Id_year");
            System.out.println("-----------------------------------");
            while (rs.next()) {
                System.out.printf("|%-3s", rs.getInt("id"));
                System.out.printf("|%-12s", rs.getString("name"));
                System.out.printf("|%-10s", rs.getInt("days_number"));
                System.out.printf("| %-4s|\n", rs.getInt("id_year"));
            }
            System.out.println("-----------------------------------");
            rs.close();
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
     
    }
       /**
        * Method which update months in table Months
       */
       public void updateDataMonths() {

        try {
            // loading the JDBC driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println(cnfe.getMessage());
            return;
        }

        // make a connection to DB
        try (Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CalendarBase", "app", "app")) {
            Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Wysyłamy zapytanie do bazy danych
            ResultSet rs = statement.executeQuery("SELECT * FROM Months");

            //adding a new row
            rs.moveToInsertRow();
            rs.updateInt("id", 100);
            rs.updateString("name", "January");
            rs.updateInt("days_number", 31);
            rs.updateInt("id_year", 2022);
            rs.insertRow();
            rs.moveToCurrentRow();
            
            // Przeglądamy otrzymane wyniki zamieniając wszystkie listery nazwiska na duże
      //      while (rs.next()) {
       //         rs.updateString("nazwisko", rs.getString("nazwisko").toUpperCase());
       //         rs.updateRow();
       //     }

          //  rs.close();
            System.out.println("Data updated");
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
    }   
       /**
        * Method which deletes data from Years table
        * @param id_year - id of the year
        */
     public void deleteDataFromYears(int id_year) {
        
        try {
            // loading the JDBC driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println(cnfe.getMessage());
            return;
        }

        // make a connection to DB
        try (Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CalendarBase", "app", "app")) {
            Statement statement = con.createStatement();
            // Usuwamy dane z tabeli
            int numberOfDeletedRows = statement.executeUpdate("DELETE FROM YEARS WHERE id_year =" + id_year);
            System.out.println("Data removed: " + numberOfDeletedRows + " rows");
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
    }
    /**
     * Method which inserts data to table Years
     * @param id_year - id of the year
     * @param isLeap - informs that the year is leap
     */
     public void insertDataYears(int id_year, boolean isLeap ) {
        
        try {
            // loading the JDBC driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println(cnfe.getMessage());
            return;
        }

        // make a connection to DB
        try (Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CalendarBase", "app", "app")) {
            Statement statement = con.createStatement();
            statement.executeUpdate("INSERT INTO YEARS VALUES ("+id_year + "," + isLeap + ")");
            System.out.println("Data inserted");
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
    }
     /**
      * Method which prints data from Years table
      */
       public void selectDataFromYears() {

        try {
            // loading the JDBC driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println(cnfe.getMessage());
            return;
        }

        // make a connection to DB
        try (Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CalendarBase", "app", "app")) {
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM YEARS");
            // Przeglądamy otrzymane wyniki
            System.out.printf("|%-3s|%-12s\n", "ID", "LEAP");
            System.out.println("-----------------------------------");
            while (rs.next()) {
                System.out.printf("|%-3s", rs.getInt("id_year"));
                System.out.printf("|%-12s", rs.getBoolean("leap"));
               
            }
            System.out.println("-----------------------------------");
            rs.close();
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
     
    }
       /**
        * Method which update data in Years Table
        */
        public void updateDataYears() {

        try {
            // loading the JDBC driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println(cnfe.getMessage());
            return;
        }

        // make a connection to DB
        try (Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CalendarBase", "app", "app")) {
            Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Wysyłamy zapytanie do bazy danych
            ResultSet rs = statement.executeQuery("SELECT * FROM YEARS");

            //adding a new row
            rs.moveToInsertRow();
            rs.updateInt("id", 100);
            rs.updateBoolean("leap", true);
            rs.insertRow();
            rs.moveToCurrentRow();
            
            // Przeglądamy otrzymane wyniki zamieniając wszystkie listery nazwiska na duże
      //      while (rs.next()) {
       //         rs.updateString("nazwisko", rs.getString("nazwisko").toUpperCase());
       //         rs.updateRow();
       //     }

          //  rs.close();
            System.out.println("Data updated");
        } catch (SQLException sqle) {
            System.err.println(sqle.getMessage());
        }
    }      
  
 
}
