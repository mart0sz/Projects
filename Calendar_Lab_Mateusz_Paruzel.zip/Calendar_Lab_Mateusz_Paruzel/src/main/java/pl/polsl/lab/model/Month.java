
package pl.polsl.lab.model;

import pl.polsl.lab.model.DayOfWeek;
import java.util.List;
/**
 * @author Mateusz Paruzel
 * @version 2.2
 */
/**
 * The class representing the month
 */
public class Month {
   private String name;
   private int numberOfDays;
   private List<DayOfWeek> days;
   private int numberOfMonths;
/**
 * Getter that returns the name of the month
 * @return name
 */
    public String getName() {
        return name;
    }
/**
 * Setter to set the month name
 * @param name - name of month
 */
    public void setName(String name) {
        this.name = name;
    }
/**
 * Getter returning the number of days in a given month
 * @return numberOfDays
 */
    public int getNumberOfDays() {
        return numberOfDays;
    }
/**
 *  Setter that sets the number of days in a given month
 * @param numberOfDays - number of days
 */
    public void setNumberOfDays(int numberOfDays) {
        this.numberOfDays = numberOfDays;
    }
/**
 * Getter that returns a list of days
 * @return days
 */
    public List<DayOfWeek> getDays() {
        return days;
    }
/**
 * A setter to set a list of the days of the month
 * @param days - list of days
 */
    public void setDays(List<DayOfWeek> days) {
        this.days = days;
    }
   /**
 * A setter to set a number of the months
 * @param liczba - number of month that we want to change
 */
   public void setNumberOfMonths(int liczba) {
       this.numberOfMonths = liczba;
   }
   /**
    * Method which checks that number of days in February and other months are correct.
    * @return true if the days number is correct, else false
    */
   public boolean checkDaysNum() {
       if(this.name == "February"){
           if(numberOfDays == 29 || numberOfDays == 28){
               return true;
           }else{
               return false;
           }
       }
       if(numberOfDays < 32 && numberOfDays > 29){
           return true;
   }
       else{
           return false;
       }
   }
/**
 * Method which returns name of montg 
 * @param nr
 * @return 
 */
   public static String monthName(int nr){
      switch (nr){
          case 0:
          return "January";
          case 1:
          return "February";
          case 2:
          return "March";
          case 3:
          return "April";
          case 4:
          return "May";
          case 5: 
          return "June";
          case 6:
          return "July";
          case 7: 
          return "August";
          case 8:
          return "September";
          case 9:
          return "October";
          case 10: 
          return "November";
          case 11:
          return "December";
 
      }
      return null;
   }
}
