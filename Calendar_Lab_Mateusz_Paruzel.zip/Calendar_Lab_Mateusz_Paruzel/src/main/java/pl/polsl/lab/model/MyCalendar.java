package pl.polsl.lab.model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import pl.polsl.lab.model.DayOfWeek;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
/**
 * @author Mateusz Paruzel
 * @version 4.2
 */

/**
 *  Class representing a calendar instance
 */
public class MyCalendar {
    private List<Year> listOfYears;
    private int currentYearNumber;
    private int currentMonthNumber;
    private int currentDayNumber;
    /**
     * Lists counting number of used dates in Calendar.
     */
       public List<Integer> month= new ArrayList<>();
       public List<Integer> year= new ArrayList<>();
/**
 * Getter is responsible for getting current year number
 * @return 
 */
    public int getCurrentYearNumber() {
        return currentYearNumber;
    }
    /**
     * Setter is responsible for setting current year number
     * @param currentYearNumber - current Year Number
     */
    public void setCurrentYearNumber(int currentYearNumber) {
        this.currentYearNumber = currentYearNumber;
    }
/**
 * Getter which returns current month number
 * @return currentMonthNumber - current Month number
 */
    public int getCurrentMonthNumber() {
        return currentMonthNumber;
    }
/**
 * Setter is responsible for setting current month in calendar
 * @param currentMonthNumber - current Month Number
 */
    public void setCurrentMonthNumber(int currentMonthNumber) {
        this.currentMonthNumber = currentMonthNumber;
    }
/**
 * Getter which returns current day number (1-31)
 * @return currentDayNumber
 */
    public int getCurrentDayNumber() {
        return currentDayNumber;
    }
    /**
     * Setter is responsible for setting the current day in calendar
     * @param currentDayNumber - current day number
     */
    public void setCurrentDayNumber(int currentDayNumber) {
        this.currentDayNumber = currentDayNumber;
    }
    
    /**
     * Getter returns list of the years
     * @return listOfYears
     */

    public List<Year> getListOfYears() {
        return listOfYears;
    }
    /**
     * Setter to list the years in the calendar
     * @param listOfYears - list of the Years
     */

    public void setListOfYears(List<Year> listOfYears) {
        this.listOfYears = listOfYears;
    }
    
 /**
 * Method that generates a calendar for today
 * @return Generated calendar for today
 */
    public static MyCalendar generateCalendarForToday() {
        int currentYear, currentMonth, currentDay;
        Calendar cal = Calendar.getInstance();
        currentYear = cal.get(Calendar.YEAR);
        currentMonth = cal.get(Calendar.MONTH);
        currentDay = cal.get(Calendar.DAY_OF_MONTH);
        
        return generateCalendarForDate(currentYear, currentMonth, currentDay);
    }
/**
 * Method that generates a calendar for a date specified by the user
 * @param currentYear - current year
 * @param currentMonth - current month
 * @param currentDay - current day
 * @return Generated calendar for specified date
 */
    public static MyCalendar generateCalendarForDate(int currentYear, int currentMonth, int currentDay) {
       MyCalendar calendar = new MyCalendar();
       calendar.setCurrentYearNumber(currentYear);
       calendar.setCurrentMonthNumber(currentMonth);
       calendar.setCurrentDayNumber(currentDay);
       
       calendar.setListOfYears(generateListOfYearsForYearPlusMinusOne(currentYear));
       return calendar;
    }
/**
 * Method that generate list of years, one forward and one back.
 * @param currentYear - current year
 * @return List of years
 */
    private static List<Year> generateListOfYearsForYearPlusMinusOne(int currentYear) {
        List<Year> years = new ArrayList<>();
        
        years.add(generateYear(currentYear-1));
        years.add(generateYear(currentYear));
        years.add(generateYear(currentYear+1));
        
        return years;
    }
/**
 * Method that generate year object with number of year
 * @param yearNumber - number of year
 * @return year
 */
    private static Year generateYear(int yearNumber) {
        Year year = new Year();
        year.setNumber(yearNumber);
        year.setListOfMonths(generateListOfMonths(yearNumber, year.isLeap()));
        return year;
        
    }
/**
 * Method that generate list of months for leap year and non-leap year, and this method also counts number of days for specified months
 * @param yearNumber - number of year
 * @param leap - is leap?
 * @return months - list of months
 */
    private static List<Month> generateListOfMonths(int yearNumber, boolean leap) {
        
        List<Month> months = new ArrayList<>();
        Month jan = new Month();
        jan.setName("January");
        jan.setNumberOfDays(31);
        jan.setDays(generateDays(31, getFirstDayOfWeek(yearNumber, 0)));
        months.add(jan);
        
        //feb
        Month feb = new Month();
        feb.setName("February");
        if(leap){
            feb.setNumberOfDays(29);
            feb.setDays(generateDays(29, getFirstDayOfWeek(yearNumber, 1)));
            
        }else{
            feb.setNumberOfDays(28);
            feb.setDays(generateDays(28, getFirstDayOfWeek(yearNumber, 1)));
        }
        months.add(feb);
        //mar
        Month mar = new Month();
        mar.setName("March");
        mar.setNumberOfDays(31);
        mar.setDays(generateDays(31, getFirstDayOfWeek(yearNumber, 2)));
        months.add(mar);
        //apr
        Month apr = new Month();
        apr.setName("April");
        apr.setNumberOfDays(30);
        apr.setDays(generateDays(30, getFirstDayOfWeek(yearNumber, 3)));
        months.add(apr);
        //may
        Month may = new Month();
        may.setName("May");
        may.setNumberOfDays(31);
        may.setDays(generateDays(31, getFirstDayOfWeek(yearNumber, 4)));
        months.add(may);
        //June
        Month jun = new Month();
        jun.setName("June");
        jun.setNumberOfDays(30);
        jun.setDays(generateDays(30, getFirstDayOfWeek(yearNumber, 5)));
        months.add(jun);
        //July
        Month jul = new Month();
        jul.setName("July");
        jul.setNumberOfDays(31);
        jul.setDays(generateDays(31, getFirstDayOfWeek(yearNumber, 6)));
         months.add(jul);
        //August
        Month aug = new Month();
        aug.setName("August");
        aug.setNumberOfDays(31);
        aug.setDays(generateDays(31, getFirstDayOfWeek(yearNumber, 7)));
        months.add(aug);
       
        //September
        Month sep = new Month();
        sep.setName("September");
        sep.setNumberOfDays(30);
        sep.setDays(generateDays(30, getFirstDayOfWeek(yearNumber, 8)));
        months.add(sep);
        //October
        Month oct = new Month();
        oct.setName("October");
        oct.setNumberOfDays(31);
        oct.setDays(generateDays(31, getFirstDayOfWeek(yearNumber, 9)));
        months.add(oct);
        
        //November
        Month nov = new Month();
        nov.setName("November");
        nov.setNumberOfDays(30);
        nov.setDays(generateDays(30, getFirstDayOfWeek(yearNumber,10)));
        months.add(nov);
        //December
        Month dec = new Month();
        dec.setName("December");
        dec.setNumberOfDays(31);
        dec.setDays(generateDays(31, getFirstDayOfWeek(yearNumber, 11)));
        months.add(dec);

        //December
        return months;
    }
    /**
     * Method which returns first day of first week in the month
     * @param yearNumber - year number
     * @param monthNumber - month number
     * @return DayOfWeek
     */
   private static DayOfWeek getFirstDayOfWeek(int yearNumber, int monthNumber){
       Calendar cal = Calendar.getInstance();
       cal.set(yearNumber, monthNumber, 1);
       int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
       return DayOfWeek.fromNum(dayOfWeek);
   }
/**
 * Method that generate days for specified months
 * @param maxDays - max days of month
 * @param firstDayOfWeek - first day of week
 * @return days - list of days
 */
    public static List<DayOfWeek> generateDays(int maxDays, DayOfWeek firstDayOfWeek) {
        List<DayOfWeek> days = new ArrayList<>();
        int firstNum = firstDayOfWeek.getNum() ;
        for(int i = 0; i<maxDays; i++){
            int currentNum = (firstNum + i)%7;
            if(currentNum == 0)
                currentNum = 7;
            days.add(DayOfWeek.fromNum(currentNum));
        }
        return days;
    }
    

}
