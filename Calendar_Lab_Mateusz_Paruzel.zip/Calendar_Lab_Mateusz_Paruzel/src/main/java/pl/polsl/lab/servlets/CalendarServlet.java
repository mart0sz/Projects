package pl.polsl.lab.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import pl.polsl.calendar_lab.exceptions.ActiveMonthNotFoundException;
import pl.polsl.calendar_lab.exceptions.ActiveYearNotFoundException;
import pl.polsl.lab.model.*;
/**
 *
 * @author Mateusz Paruzel
 * @version 4.2
 */
@WebServlet(name = "CalendarServlet", urlPatterns = {"CalendarServlet"})
public class CalendarServlet extends HttpServlet {
    
    private MyCalendar calendar;
    private int activeMonthNumber;
    private int activeYearNumber;
    private String  activeNameOfDay;
    private int firstD = 0;
    private int maxDays = 0;
    @Override
    /**
     * Method which initializes data for servlet
     */
    public void init() {
        
      Database data = new Database();
      data.createTables();
      data.insertDataMonths("January", 31, 2022);
    
    }
    /**
     * Getter which returns active year in calendar
     * @return
     * @throws ActiveYearNotFoundException 
     */
    private Year getActiveYear() throws ActiveYearNotFoundException{
       
        for (Year year : calendar.getListOfYears()) {
            if (year.getNumber() == activeYearNumber){
                return year;
            }
        }
       throw new ActiveYearNotFoundException("Active year: " + activeYearNumber + " not found!");
    }
 /**
     * Getter which returns active month. 
     * @return month
     * @throws ActiveYearNotFoundException 
     */
    private Month getActiveMonth() throws ActiveYearNotFoundException, ActiveMonthNotFoundException{
        for(int i = 0; i<12; i++){
                if(i == activeMonthNumber) {
                    return getActiveYear().getListOfMonths().get(i);
            }
                
        }
        throw new ActiveMonthNotFoundException("Active month: " + activeMonthNumber+ " not found!");
    }
    /**
     * Getter which returns active day numer
     * @return int Day number
     */
    private int getActiveDays(){
        return calendar.getCurrentDayNumber();
    }
     private int findFirstDay() throws ActiveYearNotFoundException, ActiveMonthNotFoundException{
       int counterC = 0;
        List days = new ArrayList<DayOfWeek>();
        days = getActiveMonth().getDays();
        Iterator<DayOfWeek> iterator = days.iterator();
          DayOfWeek d = (DayOfWeek) days.get(0);
         activeNameOfDay = d.getName();
         switch(activeNameOfDay){
             case "Sunday":
                 break;
             case "Monday":
                 counterC = 1;
                 break;
             case "Tuesday":
                 counterC = 2;
                 break;
             case "Wednesday":
                 counterC = 3;
                 break;
             case "Thursday":
                 counterC = 4;
                 break;
             case "Friday":
                 counterC = 5;
                 break;
             case "Saturday":
                 counterC = 6;
                 break;
         }    
         return counterC;
     }
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * This method completes the array generated in html
     */
void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
           
            
         String miesiac = request.getParameter("inputText1");
         String  rok = request.getParameter("inputText2");
         try{
             int miesiacInt = Integer.parseInt(miesiac);
             int rokInt = Integer.parseInt(rok);
             calendar = MyCalendar.generateCalendarForDate(rokInt, miesiacInt-1, 1);
             calendar.month.add(miesiacInt);
             calendar.year.add(rokInt);
             HttpSession session = request.getSession();
             session.setAttribute("MyCalendar", calendar);
             Object obj=session.getAttribute("MyCalendar");
             if(obj==null){
                 calendar= new MyCalendar();
             }
             else{
                 calendar =(MyCalendar) obj;
             }
            Cookie []cookies = request.getCookies();
            int tempcounter = 0;
            for(Cookie c:cookies)
            {
                if(c.getName().equals("counter"))
                {
                    tempcounter=Integer.parseInt(c.getValue());
                }

            }
             activeMonthNumber = calendar.getCurrentMonthNumber();
             activeYearNumber = calendar.getCurrentYearNumber();
             firstD = findFirstDay();
             Calendar cal = Calendar.getInstance();
             cal.set(Calendar.YEAR, activeYearNumber);
            cal.set(Calendar.MONTH, activeMonthNumber);
            maxDays = cal.getActualMaximum(Calendar.DATE);
            
               int d = 1;
            PrintWriter out = response.getWriter();
            out.println("_");
            out.println(Month.monthName(activeMonthNumber) + "   "  + calendar.getCurrentYearNumber());
            out.println("_");
        out.println("<tr>");
        for(int k = 0; k<firstD; k++)
        {
            out.println("<td>");
            out.println("");
            out.println("</td>");
        }
            out.println("<td>");
            out.println(d++);
            out.println("</td>");
        for(int c = firstD; c<6 ; c++)
        {
            out.println("<td>");
            out.println(d++);
            out.println("</td>");
        }
         out.println("</tr>");
           for(int i = 0; i < 5; i++)
        {
            out.println("<tr>");
             for(int j = 0; j<7; j++)
           {
                if(d > maxDays)
               {
                    break;
               }    
                out.println("<td>");
                out.println(d++);
                out.println("</td>");
              
           }
             out.println("</tr>");
             
        }   
           Cookie cookie = new Cookie("counter",tempcounter+"");
            response.addCookie(cookie);
    }
          catch (NumberFormatException exc){
              response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Dane nie sa liczbami!");
        } catch (ActiveYearNotFoundException ex) {
            Logger.getLogger(CalendarServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ActiveMonthNotFoundException ex) {
            Logger.getLogger(CalendarServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
            
         
}    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         
        processRequest(request, response);
          
        ServletContext ser = getServletContext();  
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
        /**
     * This method is saving informations from list of customers to .txt file
     * @param listOfCustomers stores list of customers
     */
}
