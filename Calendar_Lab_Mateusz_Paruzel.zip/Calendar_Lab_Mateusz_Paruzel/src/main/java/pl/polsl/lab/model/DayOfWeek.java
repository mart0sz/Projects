/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package pl.polsl.lab.model;

import java.util.Calendar;
/**
 * @author Mateusz Paruzel
 * @version 2.2
 */
/**
 * Enum representing the days of the week
 */
        
public enum DayOfWeek {
    SUNDAY("Sunday", Calendar.SUNDAY),
    MONDAY("Monday",Calendar.MONDAY),
    TUESDAY("Tuesday", Calendar.TUESDAY),
    WEDNESDAY("Wednesday", Calendar.WEDNESDAY),
    THURSDAY("Thursday", Calendar.THURSDAY),
    FRIDAY("Friday", Calendar.FRIDAY),
    SATURDAY("Saturday", Calendar.SATURDAY);
    private String name;
    private int num;
  
  /**
   * Constructor that sets the name and number of the day of the week
   * @param name - name of day
   * @param num  - number of day
   */
   private DayOfWeek(String name, int num) {
        this.name = name;
        this.num = num;
    }
/**
 * Getter which returns the name of the day of the week
 * @return name
 */
    public String getName() {
        return name;
    }
/**
 * Getter which returns the number of the day of the week
 * @return num
 */
    public int getNum() {
        return num;
    }
   /**
    * The method checks if the number of the day of the week in the calendar matches the number declared in the enum
    * @param num - number of day
    * @return values/null
    */
    public static DayOfWeek fromNum(int num) {
        
        final DayOfWeek[] values = DayOfWeek.values();
        for (int i = 0; i < 7; i++) {
            if (values[i].getNum() == num) {
                return values[i];
            }
        }
        return null;
    }
    
}
