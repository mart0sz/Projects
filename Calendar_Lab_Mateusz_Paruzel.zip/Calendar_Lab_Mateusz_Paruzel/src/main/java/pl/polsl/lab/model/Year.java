package pl.polsl.lab.model;

import pl.polsl.lab.model.Month;
import java.util.List;
/**
 * @author Mateusz Paruzel
 * @version 2.2
 */
/**
 *Class representing the year
 */
public class Year {
    private int number;
    private List<Month> listOfMonths;
/**
 *Getter which returns the year
 * @return int number
 */
 
    public int getNumber() {
        return number;
    }
    /**
     * Setter which sets the year
     * @param number 
     */

    public void setNumber(int number) {
        this.number = number;
    }
/**
 * Getter that returns a list of months
 * @return listOfMonths
 */
    public List<Month> getListOfMonths() {
        return listOfMonths;
    }
    /**
     *Setter that sets the list of months
     * @param listOfMonths 
     */

    public void setListOfMonths(List<Month> listOfMonths) {
        this.listOfMonths = listOfMonths;
    }
    /**
     * Method that checks if a given year is a leap yeary
     * @return true/false 
     */
    public boolean isLeap(){
        return number%4 == 0;
    }
    
}
