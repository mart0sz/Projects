/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl.polsl.calendar_lab.exceptions;
/**
 * @author Mateusz Paruzel
 * @version 4.2
 */
 /**
 * Class which represents throws exceptions
 * 
 */
public class ActiveMonthNotFoundException extends Exception {

    public ActiveMonthNotFoundException(String string) {
        super(string);
    }
    
}
