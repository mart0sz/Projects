
package pl.polsl.calendar_lab.exceptions;
/**
 * @author Mateusz Paruzel
 * @version 4.2
 * This package contains exceptions and their handling
 */