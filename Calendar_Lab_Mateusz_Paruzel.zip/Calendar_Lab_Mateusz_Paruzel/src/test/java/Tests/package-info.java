
package Tests;
/**
 * @author Mateusz Paruzel
 * @version 2.2
 * The package contains JUnit tests
 */