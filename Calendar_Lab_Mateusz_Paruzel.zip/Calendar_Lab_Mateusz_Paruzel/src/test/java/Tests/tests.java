/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Tests;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import pl.polsl.lab.model.*;
/**
 *
 * @author matip
 */
/**
 * Class representing unit tests
 */
public class tests {
    
  /**
 * @author Mateusz Paruzel
 * @version 2.2
 */



public tests() {
    }
    Month jan = new Month();
  
   List<DayOfWeek>days = new ArrayList<>(); 
 @BeforeEach
 /**
  * A method that initializes the variables used for tests
  */       
 void initialize(){
     jan.setName("February");
     jan.setNumberOfDays(28);
    
 }
 @Test
 /**
  * Test to check if the month name is not NULL
  */        
 void checkNotNullTest()
 {
     assertNotNull(jan.getName());
 }
   
 /**
  * Test to check if the number of days in a month is appropriate
  */
  @Test
  void checkDaysNumTest(){
      assertTrue(jan.checkDaysNum(), "Liczba dni jest nieprawidłowa");
  }
  @Test
   /**
    * A test to check if the calendar returns the current month and if it is correctly generated
    */ 
  void checkCurrentMonthNumberTest(){
     MyCalendar m = new MyCalendar();
     m = MyCalendar.generateCalendarForToday();
     Calendar c = Calendar.getInstance();
     assertEquals(m.getCurrentMonthNumber(), c.get(Calendar.MONTH));
  }
}